
<?php
echo "Hello World!";
?>
