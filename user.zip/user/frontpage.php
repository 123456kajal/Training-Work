<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="insert.css">
</head>
<body>
    <div class="dropdown">
        <button class="dropbtn">Insert</button>
        <div class="dropdown-content">
            <a href="insert.php">student </a>
            <a href="insertmentor.php">Mentor</a>
            <a href="insertteacher.php"> Teachers</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">SORT</button>
        <div class="dropdown-content">
            <a href="sorting.php">CRN </a>
            <a href="sortbyname.php">Name</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">
        <a href="search.php">SEARCH</a></button> 
        </div>
    </div>
</body>
</html>